﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace MizuWebSiteTest.Pages
{
    class HomePage
    {
        private IWebDriver Driver;

        public HomePage(IWebDriver driver)
        {
            Driver = driver;
        }

        IWebElement closePopup => Driver.FindElement(By.XPath("/html/body/main/div[1]/div[1]/div[1]/div[1]/a/span"));
        IWebElement lnkMyAccount => Driver.FindElement(By.LinkText("My Account"));
        public void ClickClose() => closePopup.Click();
        public bool IsMyAccountText() => lnkMyAccount.Displayed;

    }
}
