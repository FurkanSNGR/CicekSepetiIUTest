﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using SeleniumExtras.PageObjects;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Telerik.JustMock;
using WindowsInput;
using WindowsInput.Native;

namespace MizuWebSiteTest.Pages
{
    public class ProductBasketPage
    {
        private IWebDriver Driver;
        public ProductBasketPage(IWebDriver driver)
        {
            Driver = driver;
        }

        IWebElement btnCart => Driver.FindElement(By.XPath("//*[@id='productDetailSend']/div/div/div/div[2]/div[6]/div[5]/button/span"));
        IWebElement textBox => Driver.FindElement(By.XPath("//*[@id='dynamicText0']"));
        IWebElement uploadFile => Driver.FindElement(By.XPath("//*[@id='2007339']"));
        IWebElement confirmDesign => Driver.FindElement(By.XPath("//*[@id='customProduct-1530324798']/div[3]/label"));
        IWebElement addToBasket => Driver.FindElement(By.XPath("//*[@id='productDetailSendMobile']/div[3]/button"));
        string basketName => Driver.FindElement(By.XPath("//*[@id='shoppingCartForm']/div/div/div[2]/div/h3/a")).Text;


        public void AddToCart()
        {
            btnCart.Click();
        }

        public void PersonalizeText()
        {
            textBox.SendKeys("Furkan Songur");
        }

        public void PersonalizePhoto()
        {
            Actions builder = new Actions(Driver);
            builder.MoveToElement(uploadFile).Click().Build().Perform();
            Thread.Sleep(2000);
            InputSimulator selectFile = new InputSimulator();
            selectFile.Keyboard.TextEntry("C:\\Users\\gs_fu\\Desktop\\test.jpg");
            Thread.Sleep(1000);
            selectFile.Keyboard.KeyPress(VirtualKeyCode.RETURN);
        }

        public void PersonalizeConfirm()
        {
            confirmDesign.Click();
        }

        public void AddBasket()
        {
            addToBasket.Click();
            Thread.Sleep(2000);
            Assert.IsTrue(basketName.Contains("Portarretratos de cristal PERSONALIZADO"), basketName + "no write");
        }
    }
    
}
