﻿using MizuWebSiteTest.Pages;
using NUnit.Framework;
using SMizuWebSiteTest.Pages;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace MizuWebSiteTest.Steps
{

    [Binding]
    public class LoginSteps
    {

        private DriverHelper _driverHelper;
        HomePage homePage;
        LoginPage loginPage;

        public LoginSteps(DriverHelper driverHelper)
        {
            _driverHelper = driverHelper;
            homePage = new HomePage(_driverHelper.Driver);
            loginPage = new LoginPage(_driverHelper.Driver);
        }


        [Given(@"I navigate to home page")]
        public void GivenINavigateToHomePage()
        {
            _driverHelper.Driver.Navigate().GoToUrl("https://www.mizu.com/en-mx/");
            Thread.Sleep(1000);
            homePage.ClickClose();
        }

        [Given(@"I navigate to login page")]
        public void GivenIGoToTheLoginPage()
        {
            _driverHelper.Driver.Navigate().GoToUrl("https://www.mizu.com/en-mx/login");
        }

        [Given(@"I enter mail and password")]
        public void GivenIEnterUsernameAndPassword(Table table)
        {
            dynamic data = table.CreateDynamicInstance();
            loginPage.EnterUserNameAndPassword(data.Mail, data.Password);
        }

        [Given(@"I click login")]
        public void GivenIClickLogin()
        {
            loginPage.ClickLogin();
            Thread.Sleep(2000);
        }

        [Then(@"I should see user logged in to the application")]
        public void ThenIShouldSeeUserLoggedInToTheApplication()
        {
            Assert.That(homePage.IsMyAccountText(), Is.True, "My Account text did not displayed");
            Thread.Sleep(1000);
        }
        
    }
}

