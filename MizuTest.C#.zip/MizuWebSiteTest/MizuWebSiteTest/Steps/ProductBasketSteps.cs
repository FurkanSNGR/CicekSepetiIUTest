﻿using MizuWebSiteTest.Pages;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using TechTalk.SpecFlow;

namespace MizuWebSiteTest.Steps
{
    [Binding]
    class ProductBasketSteps
    {
        private DriverHelper _driverHelper;

        ProductBasketPage basketPage;
        public ProductBasketSteps(DriverHelper driverHelper)
        {
            _driverHelper = driverHelper;
            basketPage = new ProductBasketPage(_driverHelper.Driver);
        }

        [Given(@"I navigate to product page")]
        public void GivenINavigateToProductPage()
        {
            _driverHelper.Driver.Navigate().GoToUrl("https://www.mizu.com/en-mx/portarretratos-de-cristal-personalizado-cancion-kcm64138299");
            Thread.Sleep(2000);
        }

        [Given(@"I click add to cart button")]
        public void ClickAddCart()
        {
            basketPage.AddToCart();
            Thread.Sleep(2000);
        }
        [Given(@"I write text")]
        public void ClickAndUpload()
        {
            basketPage.PersonalizeText();
            Thread.Sleep(1000);
        }
        
        [Given(@"I upload file")]
        public void PersonalizePhoto()
        {
            basketPage.PersonalizePhoto();
        }
        
        [Given(@"I confirm design")]
        public void PersonalizeConfirm()
        {
            basketPage.PersonalizeConfirm();
            Thread.Sleep(2000);
        }
        
        [Then(@"I add the product to the basket")]
        public void AddBasket()
        {
            basketPage.AddBasket();
        }
    }
}
