﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace MizuWebSiteTest
{
    public class DriverHelper
    {
        public IWebDriver Driver { get; set; }
    }
}
