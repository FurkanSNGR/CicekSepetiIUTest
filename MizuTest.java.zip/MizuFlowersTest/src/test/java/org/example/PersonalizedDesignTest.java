package org.example;

import base.Base;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.CartTwoPage;
import pages.LoginPage;
import pages.ProductTwoPage;

public class PersonalizedDesignTest extends Base {
    LoginPage loginPage = new LoginPage(webDriver,webDriverWait);
    String email = "fosoj55311@unigeol.com";
    String password = "Test1234";
    ProductTwoPage productTwoPage = new ProductTwoPage(webDriver,webDriverWait);
    CartTwoPage cartTwoPage = new CartTwoPage(webDriver,webDriverWait);
    String description = "Why do we fall asleep?";

    @BeforeTest
    public void beforeMethod(){
        super.setUp();
    }

    @Test(priority = 1)
    public void fillEmail(){
        loginPage.fillEmail(email);
    }

    @Test(priority = 2)
    public void fillPassword(){
        loginPage.fillPassword(password);
    }

    @Test(priority = 3)
    public void clickLogin(){
        loginPage.clickLoginButton();
    }

    @Test(priority = 4)
    public void getToProductPage() {
        productTwoPage.getToProduct();
    }

    @Test(priority = 5)
    public void addToCart() {
        productTwoPage.addToCart();
    }

    @Test(priority = 6)
    public void fillText() {
        cartTwoPage.fillText(description);
    }

    @Test(priority = 7)
    public void uploadPhoto() throws InterruptedException {
        cartTwoPage.uploadPhoto("C:\\Users\\gs_fu\\Desktop\\test.jpg");
    }

    @Test(priority = 8)
    public void checkBox(){
        cartTwoPage.checkConfirmation();
    }

    @Test(priority = 9)
    public void clickNext(){
        cartTwoPage.clickNext();
    }

    @AfterTest
    public void afterMethod(){
        super.tearDown();
    }


}
