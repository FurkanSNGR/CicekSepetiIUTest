package org.example;

import base.Base;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.CheckoutPage;
import pages.FlowersPage;
import pages.LoginPage;
import pages.ProductPage;

public class FlowersTest extends Base {
    LoginPage loginPage = new LoginPage(webDriver,webDriverWait);
    String email = "fosoj55311@unigeol.com";
    String password = "Test1234";
    FlowersPage flowersPage = new FlowersPage(webDriver,webDriverWait);
    ProductPage productPage = new ProductPage(webDriver,webDriverWait);
    String district = "Mexico City Marriott Reforma Hotel";
    CheckoutPage checkoutPage = new CheckoutPage(webDriver,webDriverWait);
    String recipientName = "Furkan Songur";
    String phoneNumber = "0000000000";
    String hotel = "Marriott Hotel";

    @BeforeTest
    public void beforeMethod(){
        super.setUp();
    }

    @Test(priority = 1)
    public void fillEmail(){
        loginPage.fillEmail(email);
    }

    @Test(priority = 2)
    public void fillPassword(){
        loginPage.fillPassword(password);
    }

    @Test(priority = 3)
    public void clickLogin() throws InterruptedException {
        loginPage.clickLoginButton();
    }

    @Test(priority = 4)
    public void getToFlowersPage() {
        flowersPage.getToFlowersPage();
    }

    @Test(priority = 5)
    public void changeCountryCode(){
        flowersPage.changeCountryCode();
    }

    @Test(priority = 6)
    public  void chooseFirstProduct(){
        flowersPage.chooseFirstProduct();
    }

    @Test(priority = 7)
    public void chooseDistrict() throws InterruptedException {
        productPage.setDistrict(district);
    }

    @Test(priority = 8)
    public void setTime(){
        productPage.setTime();
    }

    @Test(priority = 9)
    public void addToCart(){
        productPage.addToCart();
    }

    @Test(priority = 10)
    public void fillRecipientName(){
        checkoutPage.fillRecipientName(recipientName);
    }

    @Test(priority = 11)
    public void fillNumber(){
        checkoutPage.fillPhoneNumber(phoneNumber);
    }

    @Test(priority = 12)
    public void fillAddress() throws InterruptedException {
        checkoutPage.fillAddress(district);
    }

    @Test(priority = 13)
    public void selectPlace(){
        checkoutPage.selectPlace(hotel);
    }

    @Test(priority = 14)
    public void clickNext(){
        checkoutPage.clickNext();
    }

    @Test(priority = 15)
    public void selectOxxo(){
        checkoutPage.selectOXXO();
    }

    @Test(priority = 16)
    public void clickPay() throws InterruptedException {
        checkoutPage.clickPay();
    }


    @AfterTest
    public void afterMethod(){
        super.tearDown();
    }
}
