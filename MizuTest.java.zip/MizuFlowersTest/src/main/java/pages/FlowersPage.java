package pages;

import base.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class FlowersPage extends Base {

    public FlowersPage(WebDriver webDriver, WebDriverWait webDriverWait){
        this.webDriver = webDriver;
        this.webDriverWait = webDriverWait;
        PageFactory.initElements(this.webDriver,this);
    }

    public void getToFlowersPage(){
        wait(By.xpath("//span[@class='icon-close']"));
        WebElement modalClose = returnElementByXpath("//span[@class='icon-close']");
        modalClose.click();
        wait(By.xpath("//a[@href='/flowers']/span[@class='main-menu__text']"));
        WebElement flowersPage = returnElementByXpath("//a[@href='/flowers']/span[@class='main-menu__text']");
        flowersPage.click();
    }

    public void changeCountryCode(){
        Actions hover = new Actions(webDriver);
        wait(By.xpath("//li[@class='globalization__item js-globalization-item test-sendto']"));
        WebElement elementToHover = returnElementByXpath("//li[@class='globalization__item js-globalization-item test-sendto']");
        hover.moveToElement(elementToHover);
        wait(By.xpath("//li[@class='globalization__item js-globalization-item test-sendto']"));
        WebElement elementMexico = returnElementByXpath("//span[text()='Mexico']");
        hover.moveToElement(elementMexico).click().build().perform();
    }

    public void chooseFirstProduct(){
        List<WebElement> elements = webDriver.findElements(By.xpath("//a[@class='products__item-link js-products__item-link']"));
        elements.get(0).click();
    }
}
