package pages;

import base.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

public class CartTwoPage extends Base {
    public CartTwoPage(WebDriver webDriver, WebDriverWait webDriverWait){
        this.webDriver = webDriver;
        this.webDriverWait = webDriverWait;
        PageFactory.initElements(this.webDriver,this);
    }

    public void fillText(String description){
        wait(By.xpath("//input[@id='dynamicText0']"));
        WebElement textForm = returnElementByXpath("//input[@id='dynamicText0']");
        textForm.sendKeys(description);
    }

    public static void setClipboardData(String string) {
        StringSelection stringSelection = new StringSelection(string);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
    }

    public static void uploadFile(String fileLocation) {
        try {
            setClipboardData(fileLocation);
            Robot robot = new Robot();

            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }

    public void uploadPhoto(String file) throws InterruptedException {
        wait(By.xpath("//div[@class='custom-image__upload-button']"));
        WebElement uploadElement = returnElementByXpath("//div[@class='custom-image__upload-button']");
        uploadElement.click();
        Thread.sleep(3000);
        uploadFile(file);
        Thread.sleep(3000);
    }

    public void checkConfirmation(){
        wait(By.xpath("//label[@class='small js-customize-confirmation-label']"));
        WebElement confirmation = returnElementByXpath("//label[@class='small js-customize-confirmation-label']");
        confirmation.click();
    }

    public void clickNext() {
        WebElement nextElement = returnElementByXpath("//button[@class='btn btn-lg btn-primary order-next-button js-add-to-cart-customize-product']");
        nextElement.click();
    }
}
