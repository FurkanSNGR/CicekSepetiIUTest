package pages;

import base.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage extends Base {

    public LoginPage(WebDriver webDriver, WebDriverWait webDriverWait){
        this.webDriver = webDriver;
        this.webDriverWait = webDriverWait;
        PageFactory.initElements(this.webDriver,this);
    }


    public void fillEmail(String email){
        WebElement emailForm = webDriver.findElement(By.xpath("//input[@id='EmailLogin']"));
        emailForm.click();
        emailForm.sendKeys(email);
    }


    public void fillPassword(String password){
        WebElement passwordForm = webDriver.findElement(By.xpath("//input[@id='Password']"));
        passwordForm.click();
        passwordForm.sendKeys(password);
    }


    public void clickLoginButton(){
        WebElement loginButton = webDriver.findElement(By.xpath("//button[@class='btn btn-primary btn-lg pull-right login__btn js-login-button']"));
        loginButton.click();
    }

}
