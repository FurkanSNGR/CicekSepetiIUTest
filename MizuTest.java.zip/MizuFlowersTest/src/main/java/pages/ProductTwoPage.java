package pages;

import base.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProductTwoPage extends Base {
    public ProductTwoPage(WebDriver webDriver, WebDriverWait webDriverWait){
        this.webDriver = webDriver;
        this.webDriverWait = webDriverWait;
        PageFactory.initElements(this.webDriver,this);
    }

    String urlOfProduct = "https://www.mizu.com/en-mx/portarretratos-de-cristal-personalizado-cancion-kcm64138299";

    public void getToProduct(){
        webDriver.get(urlOfProduct);
    }

    public void addToCart(){
        wait(By.xpath("//span[@class='product__action-button-text']"));
        WebElement addToCartElement = returnElementByXpath("//span[@class='product__action-button-text']");
        addToCartElement.click();
    }


}
