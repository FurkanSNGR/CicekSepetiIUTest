package pages;

import base.Base;
import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class ProductPage extends Base {

    public ProductPage(WebDriver webDriver, WebDriverWait webDriverWait){
        this.webDriver = webDriver;
        this.webDriverWait = webDriverWait;
        PageFactory.initElements(this.webDriver,this);
    }

    public void setDistrict(String district) throws InterruptedException {
        WebElement districtElement = returnElementByXpath("//input[@class='js-emoji-characters js-html-tag-replace']");
        districtElement.sendKeys(district);
        Thread.sleep(2000);
        districtElement.sendKeys(Keys.ARROW_DOWN);
        districtElement.sendKeys(Keys.ENTER);
    }

    public void setTime(){
        wait(By.xpath("//div[@class='product__dates-col']"));
        List<WebElement> elements = webDriver.findElements(By.xpath("//div[@class='product__dates-col']"));
        elements.get(2).click();
        wait(By.xpath("//select[@class='select-green']"));
        WebElement timeSelectElement = returnElementByXpath("//select[@class='select-green']");
        Select timeSelectElementObj = new Select(timeSelectElement);
        timeSelectElementObj.selectByVisibleText("17:00-21:00");
    }

    public void addToCart(){
        WebElement addToCartElement = webDriver.findElement(By.xpath("//span[@class='product__action-button-text']"));
        addToCartElement.click();
    }
}
