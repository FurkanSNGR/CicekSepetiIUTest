package pages;

import base.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CheckoutPage extends Base {

    public CheckoutPage(WebDriver webDriver, WebDriverWait webDriverWait){
        this.webDriver = webDriver;
        this.webDriverWait = webDriverWait;
        PageFactory.initElements(this.webDriver,this);
    }

    public void fillRecipientName(String name){
        wait(By.xpath("//input[@id='GroupDeliveryAddressList_0__Address_AddressName']"));
        WebElement recipientName = returnElementByXpath("//input[@id='GroupDeliveryAddressList_0__Address_AddressName']");
        recipientName.sendKeys(name);
    }

    public void fillPhoneNumber(String phoneNumber){
        wait(By.xpath("//input[@id='GroupDeliveryAddressList_0__Address_Phone_Phone']"));
        WebElement recipientPhoneNumber = returnElementByXpath("//input[@id='GroupDeliveryAddressList_0__Address_Phone_Phone']");
        recipientPhoneNumber.sendKeys(phoneNumber);
    }

    public void fillAddress(String address) throws InterruptedException {
        wait(By.xpath("//input[@placeholder = 'Find your address']"));
        WebElement addressList = returnElementByXpath("//input[@placeholder = 'Find your address']");
        addressList.sendKeys(address);
        Thread.sleep(2000);
        addressList.sendKeys(Keys.ARROW_DOWN);
        addressList.sendKeys(Keys.ENTER);
    }

    public void selectPlace(String hotel){
        wait(By.xpath("//input[@placeholder = 'Delivery Location']"));
        WebElement placeElement = returnElementByXpath("//input[@placeholder = 'Delivery Location']");
        placeElement.click();
        wait(By.xpath("//div[@class='selectize-dropdown single framed-selectbox js-selectize required-selectize js-sending-place js-selectize-region plugin-start_typing plugin-preserve_on_blur']/div/div[text()='Hotel']"));
        WebElement selectHotel = returnElementByXpath("//div[@class='selectize-dropdown single framed-selectbox js-selectize required-selectize js-sending-place js-selectize-region plugin-start_typing plugin-preserve_on_blur']/div/div[text()='Hotel']");
        selectHotel.click();
        wait(By.xpath("//input[@id='GroupDeliveryAddressList_0__Address_SendingPlaceValue']"));
        WebElement sendingPlaceValueElement = returnElementByXpath("//input[@id='GroupDeliveryAddressList_0__Address_SendingPlaceValue']");
        sendingPlaceValueElement.sendKeys(hotel);
    }

    public void clickNext() {
        WebElement nextElement = returnElementByXpath("//button[@class='btn btn-lg btn-primary order-next-button js-submit-form']");
        nextElement.click();
        wait(By.xpath("//button[@class='btn btn-lg btn-primary order-next-button js-submit-form']"));
        WebElement nextElement1 = returnElementByXpath("//button[@class='btn btn-lg btn-primary order-next-button js-submit-form']");
        nextElement1.click();
        wait(By.xpath("//button[@class='btn btn-lg btn-primary order-next-button js-submit-form']"));
        WebElement nextElement2 = returnElementByXpath("//button[@class='btn btn-lg btn-primary order-next-button js-submit-form']");
        nextElement2.click();
    }

    public void selectOXXO(){
        wait(By.xpath("//label[text()='OXXO']"));
        WebElement oxxoElement = returnElementByXpath("//label[text()='OXXO']");
        oxxoElement.click();
    }

    public void clickPay() throws InterruptedException {
        Thread.sleep(3000);
        WebElement payElement = returnElementByXpath("//button[text()='Pay']");
        payElement.click();
        wait(By.xpath("//button[@class='btn btn-primary']"));
        WebElement agreeButton = returnElementByXpath("//button[@class='btn btn-primary']");
        agreeButton.click();
        wait(By.xpath("//button[text()='Pay']"));
        WebElement payElement2 = returnElementByXpath("//button[text()='Pay']");
        payElement2.click();
        Thread.sleep(5000);
    }
}
