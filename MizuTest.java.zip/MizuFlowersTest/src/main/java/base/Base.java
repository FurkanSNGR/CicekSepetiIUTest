package base;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class Base {

    protected static WebDriver webDriver;
    protected static WebDriverWait webDriverWait;

    public void setUp(){
        System.setProperty("webdriver.chrome.driver","src/resources/chromedriver.exe");
        webDriver = new ChromeDriver();
        webDriverWait = new WebDriverWait(webDriver,30);
        String baseUrl = "https://www.mizu.com/login";
        webDriver.get(baseUrl);
        webDriver.manage().window().maximize();
    }
    public WebElement returnElementByXpath(String xpath){
        return webDriver.findElement(By.xpath(xpath));
    }

    public WebElement wait(By by){
        return webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(by));
    }

    public void tearDown(){
        webDriver.close();
        webDriver.quit();
    }
}

